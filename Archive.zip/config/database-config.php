<?php
// config/database-config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration
class DatabaseConfig {
    private $host = 'localhost';
    private $db_name = 'linkedin_automtion';
    private $username = 'root';
    private $password = '';
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            
            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]);
            
        } catch(PDOException $exception) {
            error_log("Database Connection Error: " . $exception->getMessage());
            die("Database connection failed. Please try again later.");
        }
        return $this->conn;
    }
}

// Initialize database connection
$database = new DatabaseConfig();
$db = $database->getConnection();

// Site Configuration
define('SITE_URL', 'https://sf.nexloadtrucking.com');
define('SITE_NAME', 'LinkedIn Automation Tool');
define('ADMIN_EMAIL', 'admin@nexloadtrucking.com');

// Multi-country settings
define('SUPPORTED_COUNTRIES', ['us', 'in']);
define('DEFAULT_COUNTRY', 'us');

// Currency settings
$CURRENCY_SETTINGS = [
    'us' => ['currency' => 'USD', 'symbol' => '$', 'name' => 'United States'],
    'in' => ['currency' => 'INR', 'symbol' => '₹', 'name' => 'India']
];

// Payment Gateway Settings
define('PAYMENT_GATEWAYS', [
    'us' => 'stripe',
    'in' => 'razorpay'
]);

// Security settings
define('SESSION_TIMEOUT', 3600); // 1 hour
define('TRIAL_PERIOD_DAYS', 14);
define('MAX_LOGIN_ATTEMPTS', 5);

// Helper Functions
function isCustomerLoggedIn() {
    return isset($_SESSION['customer_id']) && isset($_SESSION['customer_email']);
}

function requireCustomerLogin() {
    if (!isCustomerLoggedIn()) {
        header('Location: login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit();
    }
}

function getCustomerCountry() {
    if (isset($_SESSION['customer_country'])) {
        return $_SESSION['customer_country'];
    }
    
    // Default to US if not set
    return DEFAULT_COUNTRY;
}

function getCurrencySettings($country = null) {
    global $CURRENCY_SETTINGS;
    
    if (!$country) {
        $country = getCustomerCountry();
    }
    
    return $CURRENCY_SETTINGS[$country] ?? $CURRENCY_SETTINGS[DEFAULT_COUNTRY];
}

function formatPrice($amount, $country = null) {
    $currency = getCurrencySettings($country);
    return $currency['symbol'] . number_format($amount, 2);
}

function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

function logCustomerActivity($customerId, $action, $details = '') {
    global $db;
    
    try {
        $stmt = $db->prepare("
            INSERT INTO customer_activity_logs (customer_id, action, details, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $customerId,
            $action,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    } catch (Exception $e) {
        error_log("Error logging customer activity: " . $e->getMessage());
    }
}

function sendJsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

function redirectTo($url) {
    header("Location: $url");
    exit();
}

// Error handling
function logError($message, $file = 'customer_error.log') {
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message" . PHP_EOL;
    
    $logPath = __DIR__ . '/../logs/' . $file;
    
    if (!is_dir(dirname($logPath))) {
        mkdir(dirname($logPath), 0755, true);
    }
    
    file_put_contents($logPath, $logMessage, FILE_APPEND | LOCK_EX);
}

// Set timezone
date_default_timezone_set('UTC');
?>