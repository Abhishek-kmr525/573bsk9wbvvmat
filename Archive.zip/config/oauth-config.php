<?php
// config/oauth-config.php
require_once 'database-config.php';

// OAuth Configuration
define('GOOGLE_CLIENT_ID', '718478991787-hsv2crpg6oascddukf2oi2022alfthdv.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', SITE_URL . '/customer/oauth/google-callback.php');

define('LINKEDIN_CLIENT_ID', '86l7ua1yey2m6q');
define('LINKEDIN_CLIENT_SECRET', 'PL_AP1.BvEMj54OkNQlOhMA.8mGsAg==');
define('LINKEDIN_REDIRECT_URI', SITE_URL . '/customer/oauth/linkedin-callback.php');

// OAuth Helper Functions
function getGoogleLoginUrl() {
    $params = array(
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'scope' => 'openid profile email',
        'response_type' => 'code',
        'access_type' => 'offline',
        'prompt' => 'consent',
        'state' => generateToken(32)
    );
    
    $_SESSION['oauth_state'] = $params['state'];
    
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
}

function getLinkedInLoginUrl() {
    $params = array(
        'response_type' => 'code',
        'client_id' => LINKEDIN_CLIENT_ID,
        'redirect_uri' => LINKEDIN_REDIRECT_URI,
        'scope' => 'r_liteprofile r_emailaddress',
        'state' => generateToken(32)
    );
    
    $_SESSION['oauth_state'] = $params['state'];
    
    return 'https://www.linkedin.com/oauth/v2/authorization?' . http_build_query($params);
}

function exchangeGoogleCodeForToken($code) {
    $data = array(
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'code' => $code,
        'grant_type' => 'authorization_code',
        'redirect_uri' => GOOGLE_REDIRECT_URI
    );
    
    $response = makeHttpRequest('https://oauth2.googleapis.com/token', $data, array(), true);
    return $response;
}

function exchangeLinkedInCodeForToken($code) {
    $data = array(
        'grant_type' => 'authorization_code',
        'code' => $code,
        'redirect_uri' => LINKEDIN_REDIRECT_URI,
        'client_id' => LINKEDIN_CLIENT_ID,
        'client_secret' => LINKEDIN_CLIENT_SECRET
    );
    
    $response = makeHttpRequest(
        'https://www.linkedin.com/oauth/v2/accessToken',
        $data,
        array('Content-Type: application/x-www-form-urlencoded'),
        true
    );
    
    return $response;
}

function getGoogleUserInfo($accessToken) {
    $headers = array('Authorization: Bearer ' . $accessToken);
    
    $response = makeHttpRequest(
        'https://www.googleapis.com/oauth2/v2/userinfo',
        null,
        $headers,
        false,
        'GET'
    );
    
    return $response;
}

function getLinkedInUserInfo($accessToken) {
    $headers = array('Authorization: Bearer ' . $accessToken);
    
    // Get profile info
    $profileResponse = makeHttpRequest(
        'https://api.linkedin.com/v2/people/~?projection=(id,firstName,lastName,profilePicture(displayImage~:playableStreams))',
        null,
        $headers,
        false,
        'GET'
    );
    
    // Get email
    $emailResponse = makeHttpRequest(
        'https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))',
        null,
        $headers,
        false,
        'GET'
    );
    
    return array(
        'profile' => $profileResponse,
        'email' => $emailResponse
    );
}

function makeHttpRequest($url, $data = null, $headers = array(), $isFormData = false, $method = 'POST') {
    $ch = curl_init();
    
    $defaultHeaders = array('Content-Type: application/json');
    $allHeaders = array_merge($defaultHeaders, $headers);
    
    $curlOptions = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $allHeaders
    );
    
    if ($method === 'POST' && $data) {
        $curlOptions[CURLOPT_POST] = true;
        if ($isFormData) {
            $curlOptions[CURLOPT_POSTFIELDS] = http_build_query($data);
            $formHeaders = array_merge(array('Content-Type: application/x-www-form-urlencoded'), $headers);
            $curlOptions[CURLOPT_HTTPHEADER] = $formHeaders;
        } else {
            $curlOptions[CURLOPT_POSTFIELDS] = json_encode($data);
        }
    }
    
    curl_setopt_array($ch, $curlOptions);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        throw new Exception("HTTP request failed: $error");
    }
    
    curl_close($ch);
    
    if ($httpCode >= 400) {
        throw new Exception("HTTP request failed with code: $httpCode. Response: $response");
    }
    
    return json_decode($response, true);
}

function createOrUpdateOAuthCustomer($provider, $userData, $country = null) {
    global $db;
    
    try {
        $email = '';
        $name = '';
        $providerId = '';
        
        if ($provider === 'google') {
            $email = $userData['email'];
            $name = $userData['name'];
            $providerId = $userData['id'];
        } elseif ($provider === 'linkedin') {
            $emailData = isset($userData['email']['elements'][0]['handle~']['emailAddress']) ? $userData['email']['elements'][0]['handle~']['emailAddress'] : '';
            $email = $emailData;
            $firstName = isset($userData['profile']['firstName']['localized']) ? $userData['profile']['firstName']['localized'] : '';
            $lastName = isset($userData['profile']['lastName']['localized']) ? $userData['profile']['lastName']['localized'] : '';
            $name = trim($firstName . ' ' . $lastName);
            $providerId = $userData['profile']['id'];
        }
        
        if (empty($email) || empty($name)) {
            throw new Exception('Unable to retrieve user information from ' . ucfirst($provider));
        }
        
        // Check if user exists
        $stmt = $db->prepare("SELECT * FROM customers WHERE email = ?");
        $stmt->execute(array($email));
        $existingCustomer = $stmt->fetch();
        
        if ($existingCustomer) {
            // Update existing customer with OAuth info
            $stmt = $db->prepare("
                UPDATE customers 
                SET oauth_provider = ?, oauth_provider_id = ?, updated_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute(array($provider, $providerId, $existingCustomer['id']));
            
            $customerId = $existingCustomer['id'];
            $customerData = $existingCustomer;
        } else {
            // Create new customer
            $trialEndsAt = date('Y-m-d H:i:s', strtotime('+' . TRIAL_PERIOD_DAYS . ' days'));
            
            $stmt = $db->prepare("
                INSERT INTO customers (
                    name, email, country, oauth_provider, oauth_provider_id,
                    subscription_status, trial_ends_at, created_at
                ) VALUES (?, ?, ?, ?, ?, 'trial', ?, NOW())
            ");
            
            $customerCountry = $country ? $country : getCustomerCountry();
            $stmt->execute(array($name, $email, $customerCountry, $provider, $providerId, $trialEndsAt));
            
            $customerId = $db->lastInsertId();
            $customerData = array(
                'id' => $customerId,
                'name' => $name,
                'email' => $email,
                'country' => $customerCountry,
                'status' => 'active',
                'subscription_status' => 'trial'
            );
        }
        
        // Log activity
        logCustomerActivity($customerId, 'oauth_login', "Logged in via $provider");
        
        // Set session
        $_SESSION['customer_id'] = $customerId;
        $_SESSION['customer_name'] = $customerData['name'];
        $_SESSION['customer_email'] = $customerData['email'];
        $_SESSION['customer_country'] = $customerData['country'];
        $_SESSION['customer_status'] = $customerData['status'];
        $_SESSION['subscription_status'] = $customerData['subscription_status'];
        
        return $customerData;
        
    } catch (Exception $e) {
        logError("OAuth customer creation error: " . $e->getMessage());
        throw $e;
    }
}
?>