<?php
// cron/post-scheduler.php
// This script should be run every minute via cron job
// Cron command: * * * * * /usr/bin/php /path/to/your/project/cron/post-scheduler.php

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/linkedin-api.php';

class PostScheduler {
    private $db;
    private $linkedinApi;
    
    public function __construct($database) {
        $this->db = $database;
        $this->linkedinApi = new LinkedInAPI($database);
    }
    
    public function processPendingPosts() {
        try {
            // Get posts that are scheduled for now or earlier and still pending
            $currentTime = date('Y-m-d H:i:s');
            
            $stmt = $this->db->prepare("
                SELECT gp.*, a.status as automation_status 
                FROM generated_posts gp
                JOIN automations a ON gp.automation_id = a.id
                WHERE gp.scheduled_time <= ? 
                AND gp.status = 'pending' 
                AND a.status = 'active'
                ORDER BY gp.scheduled_time ASC
                LIMIT 10
            ");
            
            $stmt->execute([$currentTime]);
            $pendingPosts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $this->log("Found " . count($pendingPosts) . " pending posts to process");
            
            foreach ($pendingPosts as $post) {
                $this->processPost($post);
                
                // Add delay between posts to avoid rate limiting
                sleep(2);
            }
            
            // Clean up old completed automations
            $this->cleanupCompletedAutomations();
            
        } catch (Exception $e) {
            $this->log("Error in processPendingPosts: " . $e->getMessage());
        }
    }
    
    private function processPost($post) {
        try {
            $this->log("Processing post ID: " . $post['id']);
            
            // Post to LinkedIn
            $response = $this->linkedinApi->createPost($post['content']);
            
            if (isset($response['id'])) {
                // Success - update post status
                $stmt = $this->db->prepare("
                    UPDATE generated_posts 
                    SET status = 'posted', 
                        linkedin_post_id = ?, 
                        posted_at = NOW(),
                        error_message = NULL
                    WHERE id = ?
                ");
                
                $stmt->execute([$response['id'], $post['id']]);
                
                $this->log("Successfully posted to LinkedIn. Post ID: " . $response['id']);
                
                // Initialize analytics record
                $this->initializeAnalytics($post['id']);
                
            } else {
                throw new Exception("LinkedIn API returned invalid response");
            }
            
        } catch (Exception $e) {
            // Error - update post status
            $errorMessage = $e->getMessage();
            $this->log("Error posting to LinkedIn: " . $errorMessage);
            
            $stmt = $this->db->prepare("
                UPDATE generated_posts 
                SET status = 'failed', 
                    error_message = ?
                WHERE id = ?
            ");
            
            $stmt->execute([$errorMessage, $post['id']]);
        }
    }
    
    private function initializeAnalytics($postId) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO post_analytics (post_id, likes_count, comments_count, shares_count, impressions)
                VALUES (?, 0, 0, 0, 0)
            ");
            $stmt->execute([$postId]);
        } catch (Exception $e) {
            $this->log("Error initializing analytics for post $postId: " . $e->getMessage());
        }
    }
    
    private function cleanupCompletedAutomations() {
        try {
            $currentDate = date('Y-m-d');
            
            // Mark automations as completed if their end date has passed
            $stmt = $this->db->prepare("
                UPDATE automations 
                SET status = 'completed' 
                WHERE end_date < ? 
                AND status = 'active'
            ");
            
            $stmt->execute([$currentDate]);
            
            $completedCount = $stmt->rowCount();
            if ($completedCount > 0) {
                $this->log("Marked $completedCount automations as completed");
            }
            
        } catch (Exception $e) {
            $this->log("Error in cleanupCompletedAutomations: " . $e->getMessage());
        }
    }
    
    public function generateMissingPosts() {
        try {
            require_once dirname(__DIR__) . '/includes/ai-handler.php';
            $aiGenerator = new AIContentGenerator($this->db);
            
            // Get active automations
            $stmt = $this->db->prepare("
                SELECT * FROM automations 
                WHERE status = 'active' 
                AND start_date <= CURDATE() 
                AND end_date >= CURDATE()
            ");
            $stmt->execute();
            $automations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($automations as $automation) {
                try {
                    $posts = $aiGenerator->generateScheduledPosts($automation['id']);
                    if (!empty($posts)) {
                        $this->log("Generated " . count($posts) . " posts for automation: " . $automation['name']);
                    }
                } catch (Exception $e) {
                    $this->log("Error generating posts for automation " . $automation['id'] . ": " . $e->getMessage());
                }
            }
            
        } catch (Exception $e) {
            $this->log("Error in generateMissingPosts: " . $e->getMessage());
        }
    }
    
    public function updatePostAnalytics() {
        try {
            // Get posted posts that need analytics updates (updated more than 1 hour ago)
            $stmt = $this->db->prepare("
                SELECT gp.*, pa.last_updated
                FROM generated_posts gp
                JOIN post_analytics pa ON gp.id = pa.post_id
                WHERE gp.status = 'posted' 
                AND gp.linkedin_post_id IS NOT NULL
                AND pa.last_updated < DATE_SUB(NOW(), INTERVAL 1 HOUR)
                ORDER BY pa.last_updated ASC
                LIMIT 5
            ");
            
            $stmt->execute();
            $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($posts as $post) {
                try {
                    // Get post statistics from LinkedIn
                    $stats = $this->linkedinApi->getPostStats($post['linkedin_post_id']);
                    
                    if ($stats) {
                        $stmt = $this->db->prepare("
                            UPDATE post_analytics 
                            SET likes_count = ?, 
                                comments_count = ?, 
                                shares_count = ?, 
                                impressions = ?,
                                last_updated = NOW()
                            WHERE post_id = ?
                        ");
                        
                        $stmt->execute([
                            $stats['likes'] ?? 0,
                            $stats['comments'] ?? 0,
                            $stats['shares'] ?? 0,
                            $stats['impressions'] ?? 0,
                            $post['id']
                        ]);
                        
                        $this->log("Updated analytics for post: " . $post['id']);
                    }
                    
                } catch (Exception $e) {
                    $this->log("Error updating analytics for post " . $post['id'] . ": " . $e->getMessage());
                }
                
                // Rate limiting
                sleep(1);
            }
            
        } catch (Exception $e) {
            $this->log("Error in updatePostAnalytics: " . $e->getMessage());
        }
    }
    
    private function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message" . PHP_EOL;
        
        // Create logs directory if it doesn't exist
        $logDir = dirname(__DIR__) . '/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logDir . '/scheduler.log', $logMessage, FILE_APPEND | LOCK_EX);
        
        // Also output to console if running from command line
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }
}

// Main execution
if (php_sapi_name() === 'cli' || !isset($_SERVER['HTTP_HOST'])) {
    // Running from command line or cron
    $scheduler = new PostScheduler($db);
    
    // Process pending posts
    $scheduler->processPendingPosts();
    
    // Generate missing posts for active automations
    $scheduler->generateMissingPosts();
    
    // Update post analytics (run less frequently)
    if (date('i') % 15 == 0) { // Every 15 minutes
        $scheduler->updatePostAnalytics();
    }
    
} else {
    // Prevent direct web access
    http_response_code(403);
    die('Access denied. This script should only be run via cron.');
}
?>

<!-- Cron Job Setup Instructions -->
<!-- 
To set up the cron job, add this line to your crontab (run: crontab -e):

# LinkedIn Automation Tool - Post Scheduler
* * * * * /usr/bin/php /path/to/your/project/cron/post-scheduler.php

This will run the scheduler every minute to check for pending posts.

Alternative cron job setup for different frequencies:

# Every 5 minutes
*/5 * * * * /usr/bin/php /path/to/your/project/cron/post-scheduler.php

# Every hour
0 * * * * /usr/bin/php /path/to/your/project/cron/post-scheduler.php

Make sure to:
1. Replace "/path/to/your/project" with the actual path to your project
2. Replace "/usr/bin/php" with the correct path to PHP on your server
3. Ensure the script has execute permissions: chmod +x /path/to/your/project/cron/post-scheduler.php
4. Create a logs directory in your project root for logging
-->

<?php
// admin/linkedin-callback.php
// Handle LinkedIn OAuth callback
require_once '../config/config.php';
require_once '../includes/linkedin-api.php';

if (isset($_GET['code'])) {
    try {
        $linkedinApi = new LinkedInAPI($db);
        $tokenResponse = $linkedinApi->exchangeCodeForToken($_GET['code']);
        
        if (isset($tokenResponse['access_token'])) {
            $_SESSION['success_message'] = 'LinkedIn connected successfully!';
        } else {
            $_SESSION['error_message'] = 'Failed to connect to LinkedIn.';
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = 'LinkedIn connection error: ' . $e->getMessage();
    }
} elseif (isset($_GET['error'])) {
    $_SESSION['error_message'] = 'LinkedIn authorization was denied or failed.';
}

// Redirect back to settings
header('Location: settings.php');
exit();
?>

<?php
// admin/logout.php
require_once '../config/config.php';

// Destroy all session data
session_destroy();

// Redirect to login page
header('Location: login.php');
exit();
?>

<?php
// admin/manage-automations.php
require_once '../config/config.php';
require_once '../includes/functions.php';

requireLogin();

$automationManager = new AutomationManager($db);
$message = '';
$error = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $automationId = (int)($_POST['automation_id'] ?? 0);
    
    try {
        switch ($action) {
            case 'toggle_status':
                $currentStatus = $_POST['current_status'] ?? '';
                $newStatus = $currentStatus === 'active' ? 'inactive' : 'active';
                
                if ($automationManager->updateAutomationStatus($automationId, $newStatus)) {
                    $message = "Automation status updated to $newStatus";
                } else {
                    throw new Exception('Failed to update automation status');
                }
                break;
                
            case 'delete':
                if ($automationManager->deleteAutomation($automationId)) {
                    $message = 'Automation deleted successfully';
                } else {
                    throw new Exception('Failed to delete automation');
                }
                break;
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get all automations
$automations = $automationManager->getAutomations();

// Get post statistics for each automation
$automationStats = [];
foreach ($automations as $automation) {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_posts,
            SUM(CASE WHEN status = 'posted' THEN 1 ELSE 0 END) as posted_count,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count
        FROM generated_posts 
        WHERE automation_id = ?
    ");
    $stmt->execute([$automation['id']]);
    $automationStats[$automation['id']] = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Automations - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar { min-height: 100vh; background: #2c3e50; }
        .sidebar .nav-link { color: #bdc3c7; padding: 15px 20px; }
        .sidebar .nav-link:hover { color: #fff; background: #34495e; }
        .main-content { background: #ecf0f1; min-height: 100vh; }
        .automation-card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .status-badge { font-size: 0.8em; }
    </style>
</head>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2">
                <div class="sidebar">
                    <div class="p-3">
                        <h5 class="text-white"><?php echo SITE_NAME; ?></h5>
                    </div>
                    <nav class="nav flex-column">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="create-automation.php">
                            <i class="fas fa-plus me-2"></i>Create Automation
                        </a>
                        <a class="nav-link active" href="manage-automations.php">
                            <i class="fas fa-cogs me-2"></i>Manage Automations
                        </a>
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-sliders-h me-2"></i>Settings
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10">
                <div class="main-content p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2>Manage Automations</h2>
                        <a href="create-automation.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Create New Automation
                        </a>
                    </div>
                    
                    <?php if ($message): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i><?php echo $message; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (empty($automations)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-robot fa-4x text-muted mb-4"></i>
                            <h4 class="text-muted">No automations found</h4>
                            <p class="text-muted mb-4">Create your first automation to start generating LinkedIn posts automatically.</p>
                            <a href="create-automation.php" class="btn btn-primary btn-lg">
                                <i class="fas fa-plus me-2"></i>Create Your First Automation
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($automations as $automation): ?>
                                <?php $stats = $automationStats[$automation['id']]; ?>
                                <div class="col-lg-6 col-xl-4">
                                    <div class="automation-card">
                                        <div class="d-flex justify-content-between align-items-start mb-3">
                                            <h5 class="mb-0"><?php echo htmlspecialchars($automation['name']); ?></h5>
                                            <span class="badge status-badge bg-<?php 
                                                echo $automation['status'] === 'active' ? 'success' : 
                                                    ($automation['status'] === 'completed' ? 'secondary' : 'warning'); 
                                            ?>">
                                                <?php echo ucfirst($automation['status']); ?>
                                            </span>
                                        </div>
                                        
                                        <p class="text-muted small mb-3">
                                            <?php echo htmlspecialchars(substr($automation['topic'], 0, 100)) . '...'; ?>
                                        </p>
                                        
                                        <div class="row text-center mb-3">
                                            <div class="col-3">
                                                <div class="small text-muted">Total</div>
                                                <div class="fw-bold"><?php echo $stats['total_posts']; ?></div>
                                            </div>
                                            <div class="col-3">
                                                <div class="small text-muted">Posted</div>
                                                <div class="fw-bold text-success"><?php echo $stats['posted_count']; ?></div>
                                            </div>
                                            <div class="col-3">
                                                <div class="small text-muted">Pending</div>
                                                <div class="fw-bold text-warning"><?php echo $stats['pending_count']; ?></div>
                                            </div>
                                            <div class="col-3">
                                                <div class="small text-muted">Failed</div>
                                                <div class="fw-bold text-danger"><?php echo $stats['failed_count']; ?></div>
                                            </div>
                                        </div>
                                        
                                        <div class="row small text-muted mb-3">
                                            <div class="col-6">
                                                <i class="fas fa-calendar me-1"></i>
                                                <?php echo date('M j', strtotime($automation['start_date'])); ?> - 
                                                <?php echo date('M j, Y', strtotime($automation['end_date'])); ?>
                                            </div>
                                            <div class="col-6">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo date('g:i A', strtotime($automation['post_time'])); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row small text-muted mb-3">
                                            <div class="col-6">
                                                <i class="fas fa-robot me-1"></i>
                                                <?php echo ucfirst($automation['ai_provider']); ?>
                                            </div>
                                            <div class="col-6">
                                                <i class="fas fa-calendar-week me-1"></i>
                                                <?php 
                                                $days = explode(',', $automation['days_of_week']);
                                                $dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                                                $selectedDays = array_map(function($day) use ($dayNames) {
                                                    return $dayNames[$day - 1];
                                                }, $days);
                                                echo implode(', ', $selectedDays);
                                                ?>
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex gap-2">
                                            <?php if ($automation['status'] !== 'completed'): ?>
                                                <form method="POST" class="flex-fill">
                                                    <input type="hidden" name="action" value="toggle_status">
                                                    <input type="hidden" name="automation_id" value="<?php echo $automation['id']; ?>">
                                                    <input type="hidden" name="current_status" value="<?php echo $automation['status']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-<?php echo $automation['status'] === 'active' ? 'warning' : 'success'; ?> w-100">
                                                        <i class="fas fa-<?php echo $automation['status'] === 'active' ? 'pause' : 'play'; ?> me-1"></i>
                                                        <?php echo $automation['status'] === 'active' ? 'Pause' : 'Resume'; ?>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <button type="button" class="btn btn-sm btn-outline-primary" 
                                                    onclick="viewPosts(<?php echo $automation['id']; ?>)">
                                                <i class="fas fa-eye me-1"></i>View Posts
                                            </button>
                                            
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="automation_id" value="<?php echo $automation['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                        onclick="return confirm('Are you sure you want to delete this automation? This will also delete all generated posts.')">
                                                    <i class="fas fa-trash me-1"></i>Delete
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Posts Modal -->
    <div class="modal fade" id="postsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Generated Posts</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="postsContent">
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function viewPosts(automationId) {
            const modal = new bootstrap.Modal(document.getElementById('postsModal'));
            const content = document.getElementById('postsContent');
            
            // Show loading spinner
            content.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            `;
            
            modal.show();
            
            // Fetch posts via AJAX
            fetch('get-posts.php?automation_id=' + automationId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        let html = '';
                        if (data.posts.length === 0) {
                            html = '<p class="text-muted text-center">No posts generated yet.</p>';
                        } else {
                            data.posts.forEach(post => {
                                const statusColor = post.status === 'posted' ? 'success' : 
                                                  (post.status === 'pending' ? 'warning' : 'danger');
                                
                                html += `
                                    <div class="border-bottom py-3">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <small class="text-muted">${formatDate(post.scheduled_time)}</small>
                                            <span class="badge bg-${statusColor}">${post.status}</span>
                                        </div>
                                        <p class="mb-2">${post.content}</p>
                                        ${post.error_message ? `<div class="alert alert-danger py-1 small">${post.error_message}</div>` : ''}
                                    </div>
                                `;
                            });
                        }
                        content.innerHTML = html;
                    } else {
                        content.innerHTML = '<div class="alert alert-danger">Error loading posts</div>';
                    }
                })
                .catch(error => {
                    content.innerHTML = '<div class="alert alert-danger">Error loading posts</div>';
                });
        }
        
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        }
    </script>
</body>
</html>